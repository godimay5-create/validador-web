# Validador Tributário — versão web (Vercel)

Site do Validador Tributário. Os **cálculos são o mesmo Python do programa desktop** (`vt/servico.py`, `motor_sn.py`, `lp.py`, `importacao.py`…),
rodando dentro do navegador pelo [Pyodide](https://pyodide.org). As telas são HTML/JavaScript. Os dados ficam no **mesmo Supabase**
(carteira `companies` + nuvem `simples_dados`), no mesmo formato. Por isso o site e o .exe podem ser usados ao mesmo tempo.

Não há servidor próprio: o Vercel só entrega os arquivos de `public/`. Ninguém tem acesso aos dados sem login, porque as tabelas exigem
usuário autenticado (rode o `seguranca_supabase.sql` do projeto desktop, se ainda não rodou).

## O que já funciona no site
- Login com o usuário da nuvem (Supabase → Authentication → Users).
- **Tabela de empresas** em cima, com Situação, Receita, Tributos calculados, Declarado, Diferença, Fator R, RBT12, Faixa e Pendência.
  Tem filtros, busca, ordenação, totais, F8 (próxima pendente) e a divisória arrastável.
- **Empresa embaixo**:
  - **Resumo:** indicadores, pendências, histórico e trilha.
  - **Apuração em 5 etapas:**
    1. Arquivos: importa XML de NF-e, NFC-e e NFS-e, PDF do PGDAS-D e ZIP.
    2. Receitas do mês.
    3. RBT12 e folha mês a mês.
    4. Memória de cálculo.
    5. Validação: justificar, revisar, concluir, reabrir e imprimir relatório.
- Troca de competência e de regime, salvar apuração, relatório da carteira para imprimir/PDF.
- Barra fina com ‹ › nas abas de trabalho (Ctrl+T abre/recolhe a tabela), modo ampliado (F11) e tamanho do texto no menu ☰.
- Envio automático para a nuvem a cada alteração (indicador "Salvo na nuvem" no topo).

## Ainda só no programa desktop
- **Lucro Presumido:** a edição (receitas por atividade, tributos e retenções) e o IRPJ/CSLL trimestral. No site, o LP mostra a memória de cálculo e a validação do que já está na nuvem.
- Simulador, Notas, Obrigações, CND e Cadastro.
- Baixar NFS-e do Portal Nacional com certificado digital e baixar notas pelo Meu Danfe. O navegador não acessa o certificado instalado no Windows.

## Publicar no Vercel (uma vez)
1. **GitHub:** crie um repositório **privado** (ex.: `validador-web`), clique em *uploading an existing file* e arraste **o conteúdo**
   desta pasta (`public/`, `py/`, `tools/`, `vercel.json`, `README.md`). Clique em *Commit changes*.
2. **Vercel:** *Add New… → Project → Import* o repositório. Em *Framework Preset* deixe **Other**, não mude mais nada e clique em **Deploy**.
   O `vercel.json` já diz que o site está em `public/` e que não há build.
3. **Supabase:** em *Authentication → URL Configuration*, coloque o endereço que o Vercel deu (ex.: `https://validador-web.vercel.app`)
   em *Site URL*.
4. Abra o endereço, entre com o seu usuário e pronto.

Depois disso, cada alteração enviada ao GitHub vira deploy automático no Vercel.

## Atualizar o motor (quando o programa desktop mudar regras ou cálculos)
```bash
python tools/montar_motor.py "C:\caminho\validador_tributario"
```
Esse comando regrava `public/motor.zip` com os módulos do desktop. Depois troque `versao` em `public/js/config.js` (ex.: `1.0.1`) e envie ao GitHub.
O navegador baixa o motor novo na próxima abertura.

## Estrutura
```
public/index.html          telas
public/css/app.css         visual
public/js/app.js           login, Supabase, tabela, empresa, etapas
public/js/motor-worker.js  carrega o Pyodide e o motor sem travar a página
public/js/config.js        URL e chave pública do Supabase, versão do motor
public/motor.zip           motor do desktop (gerado por tools/montar_motor.py)
public/py/pypdf-*.whl      leitor de PDF do PGDAS-D (instalado no navegador quando aparece um PDF)
py/web.py                  ponte entre a tela e o motor (entra no motor.zip)
py/supabase_rest_web.py    substitui o cliente de rede do desktop (no site, quem fala com o Supabase é o JavaScript)
```

## Observações
- A primeira abertura baixa uns 10 MB (o Python do navegador). Das próximas vezes vem do cache e abre bem mais rápido.
- Na primeira vez, o navegador já deixa selecionadas as empresas que têm dados na nuvem. A seleção fica gravada neste navegador.
- Se duas pessoas mexerem na mesma empresa e competência ao mesmo tempo, vale a última gravação (é o mesmo comportamento do .exe).
