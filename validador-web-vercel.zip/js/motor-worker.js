/* Worker do motor: carrega o Pyodide + o motor do Validador (motor.zip) e executa as chamadas da tela
   sem travar a página. Mensagens: {id, fn, args} → {id, ok, valor | erro}. */
const PYODIDE = 'https://cdn.jsdelivr.net/pyodide/v0.27.7/full/';
importScripts(PYODIDE + 'pyodide.js');

let web = null;
let pronto = null;

async function iniciar(versao) {
  self.postMessage({ tipo: 'progresso', txt: 'Carregando o Python no navegador…' });
  const py = await loadPyodide({ indexURL: PYODIDE });
  self.postMessage({ tipo: 'progresso', txt: 'Carregando o motor de cálculo…' });
  const r = await fetch('/motor.zip?v=' + encodeURIComponent(versao || ''));
  if (!r.ok) throw new Error('Não consegui baixar o motor (motor.zip).');
  py.unpackArchive(new Uint8Array(await r.arrayBuffer()), 'zip', { extractDir: '/app' });
  py.runPython("import sys; sys.path.insert(0, '/app')");
  self.py = py;
  web = py.pyimport('web');
  self.postMessage({ tipo: 'progresso', txt: 'Motor pronto.' });
}

async function garantirPdf() {
  // PDF do PGDAS-D: o motor usa pypdf (puro Python), instalado só quando aparece um PDF
  if (self._pypdf) return;
  await self.py.loadPackage('micropip');
  const micropip = self.py.pyimport('micropip');
  await micropip.install(self.location.origin + '/py/pypdf-5.9.0-py3-none-any.whl');   // cópia no próprio site
  self._pypdf = true;
}

self.onmessage = async (ev) => {
  const { id, fn, args, versao } = ev.data;
  try {
    if (fn === '__iniciar') {
      pronto = pronto || iniciar(versao);
      await pronto;
      return self.postMessage({ id, ok: true, valor: null });
    }
    await pronto;
    let valor;
    if (fn === 'importar') {
      const lista = args[0];
      if (lista.some(([n]) => /\.(pdf|zip)$/i.test(n))) await garantirPdf();
      const pyLista = self.py.toPy(lista.map(([n, b]) => [n, b]));
      valor = web.importar(pyLista);
      pyLista.destroy();
    } else if (fn === 'iniciar') {
      valor = web.iniciar(args[0], args[1], args[2], (cfg) => self.postMessage({ tipo: 'cfg', cfg }));
    } else {
      valor = web[fn](...args);
    }
    self.postMessage({ id, ok: true, valor });
  } catch (e) {
    self.postMessage({ id, ok: false, erro: String(e && e.message || e) });
  }
};
