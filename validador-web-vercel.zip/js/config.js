// Projeto Supabase (o mesmo do programa desktop). A chave é a pública ("publishable"):
// o acesso aos dados depende do login, por causa das políticas do seguranca_supabase.sql.
export const CONFIG = {
  url: 'https://naljpkfxtfrwdvzbfcry.supabase.co',
  chave: 'sb_publishable_1hv2t1uxAhAMc20bn-6ZKQ_7saYcfKP',
  tabelaCarteira: 'companies',
  colNome: 'razao_social',
  tabelaNuvem: 'simples_dados',
  versao: '1.0.0',          // mude ao publicar um motor novo (força o navegador a baixar o motor.zip de novo)
};
