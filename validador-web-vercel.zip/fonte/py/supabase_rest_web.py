"""Versão web: a conversa com o Supabase é feita pelo JavaScript (supabase-js).
Aqui ficam só os nomes que o motor importa."""
URL_PADRAO = 'https://naljpkfxtfrwdvzbfcry.supabase.co'
CHAVE_PADRAO = 'sb_publishable_1hv2t1uxAhAMc20bn-6ZKQ_7saYcfKP'


class ErroSupabase(Exception):
    pass


def traduz_erro(m, tabela='companies'):
    return str(m)


class Supabase:
    def __init__(self, url=URL_PADRAO, key=CHAVE_PADRAO):
        self.url, self.key = url, key
        self.token = None
        self.user_id = None
        self.email = ''
